import os
from telegram.ext import Application, CommandHandler

TOKEN = os.environ.get("TOKEN")

async def start(update, context):
    await update.message.reply_text("Monu Bhai X Bot Activated ✅")

app = Application.builder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))

print("Bot running...")
app.run_polling()
